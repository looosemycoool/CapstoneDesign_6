#상위 폴더의 data/ 문서 읽기
#문서 청크 분할
#각 청크에서 LLM으로 triplet 추출
#Neo4j에 MERGE로 삽입
#결과 확인


import sys
import json
import re
from pathlib import Path

from neo4j import GraphDatabase
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

# --------------------------------------------------
# 0. 상위 폴더 import 가능하게 경로 추가
# graph/build_graph_from_docs.py 에서
# 상위 폴더(vector_rag.py, data/) 접근하려고 필요
# --------------------------------------------------
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
sys.path.append(str(PROJECT_ROOT))
# --------------------------------------------------
# 1. 기존 벡터 코드에서 문서 로드/분할 함수 재사용
# 파일명이 vector_rag.py가 아니면 여기 수정
# --------------------------------------------------
from vector_rag import load_documents, split_documents

# --------------------------------------------------
# 2. 환경변수 로드
# --------------------------------------------------
load_dotenv()

# --------------------------------------------------
# 3. 경로 설정
# --------------------------------------------------
DATA_DIR = PROJECT_ROOT / "data"

# --------------------------------------------------
# 4. Neo4j 연결
# --------------------------------------------------
driver = GraphDatabase.driver(
    "bolt://localhost:7687",
    auth=("neo4j", "test1234")
)

# --------------------------------------------------
# 5. LLM 설정
# --------------------------------------------------
llm = ChatOpenAI(
    model="gpt-4o",
    temperature=0
)

# --------------------------------------------------
# 6. Neo4j 라벨/관계명 정리 함수
# --------------------------------------------------
def sanitize_identifier(text: str) -> str:
    """
    Neo4j 라벨/관계 타입은 공백, 특수문자 쓰면 귀찮아지므로 정리
    """
    if not text:
        return "Entity"
    text = text.strip()
    text = re.sub(r"[^A-Za-z0-9_]", "", text)
    if not text:
        return "Entity"
    if text[0].isdigit():
        text = "X" + text
    return text

# --------------------------------------------------
# 7. JSON 파싱 보조 함수
# --------------------------------------------------
def extract_json_array(text: str):
    """
    LLM이 ```json ... ``` 형태로 줄 수도 있어서
    JSON 배열 부분만 최대한 뽑아냄
    """
    text = text.strip()

    # 코드펜스 제거
    text = text.replace("```json", "").replace("```", "").strip()

    # JSON 배열 찾기
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        text = match.group(0)

    try:
        data = json.loads(text)
        if isinstance(data, list):
            return data
        return []
    except Exception:
        return []

# --------------------------------------------------
# 8. 청크 -> triplet 추출
# --------------------------------------------------
def extract_graph_triplets(text: str, source_name: str):
    prompt = f"""
너는 학사 문서를 지식그래프용 triplet으로 구조화하는 시스템이다.

아래 텍스트에서 "개체-관계-개체" 구조를 추출하라.

반드시 JSON 배열만 출력하라.
설명, 문장, 마크다운, 코드블록 없이 JSON만 출력하라.

각 원소는 반드시 아래 키를 포함해야 한다:
- source_type
- source_name
- relation
- target_type
- target_name

추출 규칙:
1. source_type / target_type 은 다음 중 하나만 사용:
   Program, Requirement, Condition, Track, Document

2. relation 은 다음 중 하나만 사용:
   HAS_REQUIREMENT, REQUIRES, HAS_TRACK, DIFFERS_FROM, ALTERNATIVE_TO, DESCRIBED_IN

3. 텍스트에 명확히 근거가 있는 정보만 추출할 것
4. 애매하면 추출하지 말 것
5. 숫자, 학점, 평점, 영어성적, 해외학점, 창업조건은 Condition으로 둘 것
6. 이 청크의 출처 문서는 "{source_name}" 이다.
   필요하면 Document 노드와 DESCRIBED_IN 관계도 추가 가능하다.

예시 출력:
[
  {{
    "source_type": "Program",
    "source_name": "글로벌소프트웨어융합전공",
    "relation": "HAS_REQUIREMENT",
    "target_type": "Requirement",
    "target_name": "졸업요건"
  }},
  {{
    "source_type": "Requirement",
    "source_name": "졸업요건",
    "relation": "REQUIRES",
    "target_type": "Condition",
    "target_name": "총 130학점 이상"
  }}
]

텍스트:
{text}
"""
    response = llm.invoke(prompt)
    triplets = extract_json_array(response.content)

    valid_source_types = {"Program", "Requirement", "Condition", "Track", "Document"}
    valid_target_types = {"Program", "Requirement", "Condition", "Track", "Document"}
    valid_relations = {
        "HAS_REQUIREMENT",
        "REQUIRES",
        "HAS_TRACK",
        "DIFFERS_FROM",
        "ALTERNATIVE_TO",
        "DESCRIBED_IN"
    }

    cleaned = []
    for t in triplets:
        if not isinstance(t, dict):
            continue

        required_keys = {"source_type", "source_name", "relation", "target_type", "target_name"}
        if not required_keys.issubset(t.keys()):
            continue

        if t["source_type"] not in valid_source_types:
            continue
        if t["target_type"] not in valid_target_types:
            continue
        if t["relation"] not in valid_relations:
            continue

        source_name_val = str(t["source_name"]).strip()
        target_name_val = str(t["target_name"]).strip()

        if not source_name_val or not target_name_val:
            continue

        cleaned.append({
            "source_type": t["source_type"],
            "source_name": source_name_val,
            "relation": t["relation"],
            "target_type": t["target_type"],
            "target_name": target_name_val
        })

    return cleaned

# --------------------------------------------------
# 9. Neo4j 삽입 함수
# --------------------------------------------------
def insert_triplet(tx, triplet: dict):
    source_type = sanitize_identifier(triplet["source_type"])
    target_type = sanitize_identifier(triplet["target_type"])
    relation = sanitize_identifier(triplet["relation"])

    query = f"""
    MERGE (a:{source_type} {{name: $source_name}})
    MERGE (b:{target_type} {{name: $target_name}})
    MERGE (a)-[:{relation}]->(b)
    """
    tx.run(
        query,
        source_name=triplet["source_name"],
        target_name=triplet["target_name"]
    )

# --------------------------------------------------
# 10. 그래프 초기화(선택)
# --------------------------------------------------
def clear_graph():
    with driver.session() as session:
        session.run("MATCH (n) DETACH DELETE n")

# --------------------------------------------------
# 11. 실행
# --------------------------------------------------
def main():
    print("1) 문서 로드 중...")
    documents = load_documents(DATA_DIR)
    print(f"로드된 문서 수: {len(documents)}")

    print("2) 문서 분할 중...")
    split_docs = split_documents(documents)
    print(f"청크 수: {len(split_docs)}")

    # 처음엔 너무 많이 돌리지 말고 일부만
    test_docs = split_docs[:10]
    print(f"3) 테스트 청크 수: {len(test_docs)}")

    # 필요하면 초기화
    # clear_graph()

    all_triplets = []

    print("4) 청크별 triplet 추출 중...")
    for idx, doc in enumerate(test_docs, start=1):
        source_name = doc.metadata.get("source", "unknown")
        text = doc.page_content

        print("\n" + "=" * 60)
        print(f"[청크 {idx}] source = {source_name}")
        print(text[:300].replace("\n", " "))

        triplets = extract_graph_triplets(text, source_name)

        print("[추출된 triplet]")
        if triplets:
            for t in triplets:
                print(t)
        else:
            print("없음")

        all_triplets.extend(triplets)

    print("\n5) Neo4j 삽입 중...")
    inserted_count = 0
    with driver.session() as session:
        for triplet in all_triplets:
            session.execute_write(insert_triplet, triplet)
            inserted_count += 1

    print(f"삽입 완료. 총 triplet 수: {inserted_count}")

    print("\n6) 결과 확인")
    with driver.session() as session:
        node_count = session.run("MATCH (n) RETURN count(n) AS c").single()["c"]
        rel_count = session.run("MATCH ()-[r]->() RETURN count(r) AS c").single()["c"]

        print(f"노드 수: {node_count}")
        print(f"관계 수: {rel_count}")

        print("\n라벨 종류:")
        label_result = session.run("MATCH (n) RETURN DISTINCT labels(n) AS labels LIMIT 20")
        for record in label_result:
            print(record["labels"])

        print("\n관계 종류:")
        rel_result = session.run("MATCH ()-[r]->() RETURN DISTINCT type(r) AS rel LIMIT 20")
        for record in rel_result:
            print(record["rel"])

if __name__ == "__main__":
    main()