from neo4j_connect import run_query

query = """
MATCH (c1:Course)-[:PREREQUISITE]->(c2:Course)
RETURN c1.name, c2.name
"""

result = run_query(query)

print(result)