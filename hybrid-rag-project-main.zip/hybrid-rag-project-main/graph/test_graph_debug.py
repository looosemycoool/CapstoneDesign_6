from neo4j_connect import run_query

print("=== 1. 전체 노드 개수 ===")
print(run_query("MATCH (n) RETURN count(n) AS node_count"))

print("\n=== 2. 전체 관계 개수 ===")
print(run_query("MATCH ()-[r]->() RETURN count(r) AS rel_count"))

print("\n=== 3. 사용 중인 라벨 보기 ===")
print(run_query("MATCH (n) RETURN DISTINCT labels(n) AS labels LIMIT 20"))

print("\n=== 4. 사용 중인 관계 타입 보기 ===")
print(run_query("MATCH ()-[r]->() RETURN DISTINCT type(r) AS rel_type LIMIT 20"))

print("\n=== 5. 샘플 노드 보기 ===")
print(run_query("MATCH (n) RETURN n LIMIT 5"))

print("\n=== 6. 샘플 관계 보기 ===")
print(run_query("MATCH (a)-[r]->(b) RETURN a, type(r) AS rel_type, b LIMIT 5"))