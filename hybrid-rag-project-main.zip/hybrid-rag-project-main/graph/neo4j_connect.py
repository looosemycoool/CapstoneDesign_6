from neo4j import GraphDatabase

driver = GraphDatabase.driver(
    "bolt://localhost:7687",
    auth=("neo4j", "test1234")
)

def run_query(query):
    with driver.session() as session:
        result = session.run(query)
        return [record.data() for record in result]